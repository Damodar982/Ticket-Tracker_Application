package com.glca.ticketTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketTrackerApplicatonApplicationTests {

	@Test
	void contextLoads() {
	}

}
