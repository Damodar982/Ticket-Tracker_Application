package com.glca.ticketTracker.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.glca.ticketTracker.entity.Ticket;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer>{

	@Query("SELECT t FROM Ticket t WHERE t.title LIKE %:title%")
	public List<Ticket>  findByTitleContainingIgnoreCase(String title);
	
	@Query("SELECT t FROM Ticket t WHERE t.shortDescription LIKE %:shortDescription%")
	public List<Ticket> findByShortDescriptionContainingIgnoreCase(String shortDescription);
}
