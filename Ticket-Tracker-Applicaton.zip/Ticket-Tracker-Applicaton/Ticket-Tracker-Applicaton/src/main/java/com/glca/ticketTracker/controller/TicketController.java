package com.glca.ticketTracker.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.glca.ticketTracker.entity.Ticket;
import com.glca.ticketTracker.service.TicketServiceImpl;

@Controller
@RequestMapping("/ticket")
public class TicketController {

	@Autowired
	public TicketServiceImpl ticketServiceImpl;

	// this method fetch give the list of tickets when we pass "/ticket/list" as a
	// request
	@RequestMapping("/list")
	public String getAllTickets(Model model) {
		List<Ticket> tickets = ticketServiceImpl.findAll();
		model.addAttribute("tickets", tickets);
		return "ticket-list";
	}

	// this "/ticket/view/tId" end point allow us to view the ticket details
	@RequestMapping("/view")
	public String getById(@RequestParam("tId") int tId, Model model) {
		Ticket tickets = ticketServiceImpl.findById(tId);
		model.addAttribute("tickets", tickets);
		return "ticket-list";
	}

	// this "/ticket/listByTitleOrDes/titleOrDes" end point will fetch the details
	// of
	// tickets details based on search by title or short description
	@RequestMapping("/listByTitleOrDes")
	public String findByTitleOrDescription(@RequestParam String titleOrDes, Model model) {
		List<Ticket> tempTicketsByT = ticketServiceImpl.findByTitleContainingIgnoreCase(titleOrDes);
		List<Ticket> tempTickets = tempTicketsByT;
		List<Ticket> tempTicketsByD = ticketServiceImpl.findByShortDescriptionContainingIgnoreCase(titleOrDes);
		for (int i = 0; i < tempTicketsByD.size(); i++) {
			tempTickets.addAll(tempTicketsByD);
		}

		model.addAttribute("tickets", tempTickets);
		return "ticket-list";
	}

	// when we pass "/ticket/showFormForAdd" as a request this method allow us to
	// add new ticket details
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model model) {
		Ticket ticket = new Ticket();
		model.addAttribute("ticket", ticket);
		return "show-form";
	}

	// when we pass "/ticket/showFormForUpdate" this method support to update the
	// ticket details
	Date previousDate;

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("tId") int id, Model model) {
		Ticket ticket = ticketServiceImpl.findById(id);
		previousDate = ticket.getCreatedOn();
		model.addAttribute("ticket", ticket);
		return "show-form";
	}

	// after entering new ticket details and click on submit this method will
	// support to save the ticket details
	// and redirect to "/ticket/list"
	@RequestMapping("/save")
	public String save(@ModelAttribute Ticket ticket) {
		if (ticket.getId() == 0) {
			Date date = new Date();
			ticket.setCreatedOn(date);
		} else
			ticket.setCreatedOn(previousDate);

		ticketServiceImpl.save(ticket);
		return "redirect:/ticket/list";
	}

	// when we click on delete button then this method will support to delete the
	// ticket details and
	// redirect to "ticket/list"
	@RequestMapping("/delete")
	public String deleteById(@RequestParam("tId") int id) {
		ticketServiceImpl.deleteById(id);
		return "redirect:/ticket/list";
	}

}
