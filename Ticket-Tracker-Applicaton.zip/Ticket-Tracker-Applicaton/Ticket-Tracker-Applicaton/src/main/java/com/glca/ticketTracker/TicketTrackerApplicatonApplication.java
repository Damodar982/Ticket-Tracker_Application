package com.glca.ticketTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketTrackerApplicatonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketTrackerApplicatonApplication.class, args);
		System.out.println("This is a train ticket tracker application");
	}

}
